#!/usr/bin/python

array = []
t=0
total_Process=raw_input("Enter Number of processes: ")
for i in range(int(total_Process)):
	array.append([])
	array[i].append(raw_input("Enter Name of Process: "))
	array[i].append(int(raw_input("Enter Arrival Time: ")))
	array[i].append(int(raw_input("Enter Burst Time: ")))
	t+=array[i][2]

array.sort(key=lambda array:array[1])

print '\n',"After FCFS Scheduling Algo, Arrangment of Processes is:",'\n'
for i in range(int(total_Process)):
	print array[i][0],'\t',array[i][1],'\t',array[i][2],'\n'
print ("Total Burst TIme is: "),t,'\n'

