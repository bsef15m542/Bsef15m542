#!/usr/bin/python

total = raw_input  ("Enter Number of Processes: ")
array = [ [0 for j in range(3)] for i in range(int(total))]

i=0
j=0
t=0
timeSlice = raw_input("Enter Time Slice: ")
for i in range(int(total)):
	array[i][j+0] = raw_input("Enter Name of processes: ")
	array[i][j+1] = int(raw_input("Enter Arrival Time of processes: "))			
	array[i][j+2] = int(raw_input("Enter Burst Time of processes: "))

array.sort(key = lambda array:array[1])

import Queue
q = Queue
q = q.Queue()

q.put(array[0])
temp = []
store=1
print '\n',"After Roubin Round Algo, Arrangment of Processes in Ready Queue is:",'\n'
while not q.empty():
	temp=q.get()
	if temp[2] > int(timeSlice):
		t=t+int(timeSlice)
		print temp
		temp[2] = temp[2]-int(timeSlice)
		if (store < int(total)):
			while t>= array[store][1]:
				q.put(array[store])
				store+=1
				if store == int(total):
					break
		q.put(temp)
	else:
		print temp
		t=t+temp[2]
		if(store < int(total)):
			while (t>array[store][1]):
				q.put(array[store])
				store+=1
				if store == int(total):
					break
