#!/usr/bin/python

total = int(raw_input  ("Enter Number of Processes: "))
array = [ [0 for j in range(4)] for i in range((total))]

i=0
j=0
for i in range((total)):
	array[i][j+0] = raw_input("Enter Name of processes: ")
	array[i][j+1] = int(raw_input("Enter Arrival Time of processes: "))			
	array[i][j+2] = int(raw_input("Enter Priority of processes: "))
	array[i][j+3] = int(raw_input("Enter Burst Time of processes: "))

array.sort(key=lambda array:array[1])

i=0
c=[]
temp=0
k=0
l=0
t=0
flag=0

print '\n',"After Priority Scheduling Algo, Arrangment of Processes is:",'\n'

for i in range((total-1)):
	print array[i]
	j=i+1
	t+=array[i][3]
	while (j<total and t >= array[j][1]):
		j+=1
	k=i+1
	l=array[k][2]
	while k<j:
		if array[k][2]<l:
			l=array[k][2]
			temp = k
			flag = 1
		k+=1
	if flag == 1:	
		c=array[i+1]
		array[i+1]=array[temp]
		array[temp]=c
		flag=0
print array[total-1] 	
